import React from 'react';
import LoginSelector from './components/LoginSelector';

function App() {
  return (
    <div>
      <LoginSelector />
    </div>
  );
}

export default App;
