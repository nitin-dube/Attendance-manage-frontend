import React from 'react';
import styles from './LoginSelector.module.css';

const LoginSelector = () => {
  return (
<div
  className={styles.body}
  style={{
    backgroundImage: `url(/niamtlogo3.png)`,
  }}
>
      <main className={styles.loginWrapper}>
        <h1>Select Login Type</h1>
        <div className={styles.loginButtons}>
          <a href="/student-login" className={`${styles.loginBtn} ${styles.student}`}>
            Login as a Student
          </a>
          <a href="/faculty-login" className={`${styles.loginBtn} ${styles.faculty}`}>
            Login as a Faculty/Admin
          </a>
        </div>
      </main>
    </div>
  );
};

export default LoginSelector;
